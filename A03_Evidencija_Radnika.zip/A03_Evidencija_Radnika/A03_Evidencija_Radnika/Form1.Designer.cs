﻿namespace A03_Evidencija_Radnika
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.IzmenaBtn = new System.Windows.Forms.Button();
            this.OpisTxt = new System.Windows.Forms.RichTextBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.BudžetTxt = new System.Windows.Forms.TextBox();
            this.DatumTxt = new System.Windows.Forms.TextBox();
            this.NazivTxt = new System.Windows.Forms.TextBox();
            this.IDTxt = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.listView1 = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.PraznjenjeBtn = new System.Windows.Forms.Button();
            this.IzlazBtn = new System.Windows.Forms.Button();
            this.BrisanjeBtn = new System.Windows.Forms.Button();
            this.UnosBtn = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pregledToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dodavanjeAngažmanaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // IzmenaBtn
            // 
            this.IzmenaBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.IzmenaBtn.Location = new System.Drawing.Point(181, 390);
            this.IzmenaBtn.Name = "IzmenaBtn";
            this.IzmenaBtn.Size = new System.Drawing.Size(144, 38);
            this.IzmenaBtn.TabIndex = 79;
            this.IzmenaBtn.Text = "Izmena projekta";
            this.IzmenaBtn.UseVisualStyleBackColor = true;
            this.IzmenaBtn.Click += new System.EventHandler(this.IzmenaBtn_Click);
            // 
            // OpisTxt
            // 
            this.OpisTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.OpisTxt.Location = new System.Drawing.Point(181, 288);
            this.OpisTxt.Name = "OpisTxt";
            this.OpisTxt.Size = new System.Drawing.Size(144, 96);
            this.OpisTxt.TabIndex = 78;
            this.OpisTxt.Text = "";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.checkBox1.Location = new System.Drawing.Point(181, 247);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(15, 14);
            this.checkBox1.TabIndex = 77;
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // BudžetTxt
            // 
            this.BudžetTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.BudžetTxt.Location = new System.Drawing.Point(181, 194);
            this.BudžetTxt.Name = "BudžetTxt";
            this.BudžetTxt.Size = new System.Drawing.Size(144, 26);
            this.BudžetTxt.TabIndex = 76;
            // 
            // DatumTxt
            // 
            this.DatumTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.DatumTxt.Location = new System.Drawing.Point(181, 150);
            this.DatumTxt.Name = "DatumTxt";
            this.DatumTxt.Size = new System.Drawing.Size(144, 26);
            this.DatumTxt.TabIndex = 75;
            // 
            // NazivTxt
            // 
            this.NazivTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.NazivTxt.Location = new System.Drawing.Point(181, 106);
            this.NazivTxt.Name = "NazivTxt";
            this.NazivTxt.Size = new System.Drawing.Size(144, 26);
            this.NazivTxt.TabIndex = 74;
            // 
            // IDTxt
            // 
            this.IDTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.IDTxt.Location = new System.Drawing.Point(181, 65);
            this.IDTxt.Name = "IDTxt";
            this.IDTxt.Size = new System.Drawing.Size(144, 26);
            this.IDTxt.TabIndex = 73;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label3.Location = new System.Drawing.Point(21, 156);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(118, 20);
            this.label3.TabIndex = 72;
            this.label3.Text = "Datum početka";
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6});
            this.listView1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.listView1.FullRowSelect = true;
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(385, 65);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(403, 319);
            this.listView1.TabIndex = 71;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            this.listView1.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Šifra";
            this.columnHeader1.Width = 50;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Naziv";
            this.columnHeader2.Width = 70;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Datum";
            this.columnHeader3.Width = 70;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Budžet";
            this.columnHeader4.Width = 70;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Završen";
            this.columnHeader5.Width = 70;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Opis";
            this.columnHeader6.Width = 70;
            // 
            // PraznjenjeBtn
            // 
            this.PraznjenjeBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.PraznjenjeBtn.Location = new System.Drawing.Point(35, 390);
            this.PraznjenjeBtn.Name = "PraznjenjeBtn";
            this.PraznjenjeBtn.Size = new System.Drawing.Size(137, 38);
            this.PraznjenjeBtn.TabIndex = 70;
            this.PraznjenjeBtn.Text = "Prazni kontrole";
            this.PraznjenjeBtn.UseVisualStyleBackColor = true;
            this.PraznjenjeBtn.Click += new System.EventHandler(this.PraznjenjeBtn_Click);
            // 
            // IzlazBtn
            // 
            this.IzlazBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.IzlazBtn.Location = new System.Drawing.Point(693, 390);
            this.IzlazBtn.Name = "IzlazBtn";
            this.IzlazBtn.Size = new System.Drawing.Size(95, 38);
            this.IzlazBtn.TabIndex = 69;
            this.IzlazBtn.Text = "Izađi";
            this.IzlazBtn.UseVisualStyleBackColor = true;
            this.IzlazBtn.Click += new System.EventHandler(this.IzlazBtn_Click);
            // 
            // BrisanjeBtn
            // 
            this.BrisanjeBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.BrisanjeBtn.Location = new System.Drawing.Point(582, 390);
            this.BrisanjeBtn.Name = "BrisanjeBtn";
            this.BrisanjeBtn.Size = new System.Drawing.Size(95, 38);
            this.BrisanjeBtn.TabIndex = 68;
            this.BrisanjeBtn.Text = "Obriši";
            this.BrisanjeBtn.UseVisualStyleBackColor = true;
            this.BrisanjeBtn.Click += new System.EventHandler(this.BrisanjeBtn_Click);
            // 
            // UnosBtn
            // 
            this.UnosBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.UnosBtn.Location = new System.Drawing.Point(440, 390);
            this.UnosBtn.Name = "UnosBtn";
            this.UnosBtn.Size = new System.Drawing.Size(121, 38);
            this.UnosBtn.TabIndex = 67;
            this.UnosBtn.Text = "Dodaj projekat";
            this.UnosBtn.UseVisualStyleBackColor = true;
            this.UnosBtn.Click += new System.EventHandler(this.UnosBtn_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label6.Location = new System.Drawing.Point(98, 288);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 20);
            this.label6.TabIndex = 66;
            this.label6.Text = "Opis";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label5.Location = new System.Drawing.Point(73, 244);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(66, 20);
            this.label5.TabIndex = 65;
            this.label5.Text = "Završen";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label4.Location = new System.Drawing.Point(79, 200);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 20);
            this.label4.TabIndex = 64;
            this.label4.Text = "Budžet";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label2.Location = new System.Drawing.Point(92, 112);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 20);
            this.label2.TabIndex = 63;
            this.label2.Text = "Naziv";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label1.Location = new System.Drawing.Point(97, 68);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 20);
            this.label1.TabIndex = 62;
            this.label1.Text = "Šifra";
            // 
            // pregledToolStripMenuItem
            // 
            this.pregledToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("pregledToolStripMenuItem.Image")));
            this.pregledToolStripMenuItem.Name = "pregledToolStripMenuItem";
            this.pregledToolStripMenuItem.Size = new System.Drawing.Size(127, 20);
            this.pregledToolStripMenuItem.Text = "Pregled projekata";
            this.pregledToolStripMenuItem.Click += new System.EventHandler(this.pregledToolStripMenuItem_Click);
            // 
            // dodavanjeAngažmanaToolStripMenuItem
            // 
            this.dodavanjeAngažmanaToolStripMenuItem.Name = "dodavanjeAngažmanaToolStripMenuItem";
            this.dodavanjeAngažmanaToolStripMenuItem.Size = new System.Drawing.Size(141, 20);
            this.dodavanjeAngažmanaToolStripMenuItem.Text = "Dodavanje Angažmana";
            this.dodavanjeAngažmanaToolStripMenuItem.Click += new System.EventHandler(this.dodavanjeAngažmanaToolStripMenuItem_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.LightSteelBlue;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pregledToolStripMenuItem,
            this.dodavanjeAngažmanaToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 61;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.IzmenaBtn);
            this.Controls.Add(this.OpisTxt);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.BudžetTxt);
            this.Controls.Add(this.DatumTxt);
            this.Controls.Add(this.NazivTxt);
            this.Controls.Add(this.IDTxt);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.PraznjenjeBtn);
            this.Controls.Add(this.IzlazBtn);
            this.Controls.Add(this.BrisanjeBtn);
            this.Controls.Add(this.UnosBtn);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button IzmenaBtn;
        private System.Windows.Forms.RichTextBox OpisTxt;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.TextBox BudžetTxt;
        private System.Windows.Forms.TextBox DatumTxt;
        private System.Windows.Forms.TextBox NazivTxt;
        private System.Windows.Forms.TextBox IDTxt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.Button PraznjenjeBtn;
        private System.Windows.Forms.Button IzlazBtn;
        private System.Windows.Forms.Button BrisanjeBtn;
        private System.Windows.Forms.Button UnosBtn;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem pregledToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dodavanjeAngažmanaToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip1;
    }
}

