﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;

namespace Nebojsa_Blagojević_A03
{
    public partial class Form1 : Form
    {
        SqlConnection Kon = new SqlConnection(@"Data Source=Komp_N\SQLEXPRESS;Initial Catalog=EIT_A03_EvidencijaRadnika;Integrated Security=True");

        SqlDataReader dr;

        int id = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            IDTxt.Enabled = false;
            PuniLV();
        }

        private void PuniLV()
        {
            listView1.Items.Clear();

            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniListView", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                ListViewItem red = new ListViewItem(dr[0].ToString());
                for (int i = 1; i < 6; i++)
                {
                    if (i == 2)
                    {
                        DateTime datum = Convert.ToDateTime(dr[i]);
                        red.SubItems.Add(datum.ToString("dd.MM.yyyy"));
                    }
                    else
                    {
                        red.SubItems.Add(dr[i].ToString());
                    }
                }
                listView1.Items.Add(red);
            }

            Kon.Close();
        }

        private void BrisiProjekat()
        {
            string datum = DateTime.Now.ToString("dd_MM_yyyy");
            string logFajl = $"log_{datum}.txt";

            Kon.Open();
            SqlCommand cmd = new SqlCommand("BrisiProjekat", Kon);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@SifraProjekta", SqlDbType.Int).Value = IDTxt.Text.ToString();
            cmd.ExecuteNonQuery();

            SqlCommand reseedCmd = new SqlCommand("DBCC CHECKIDENT ('Projekat', RESEED, 0)", Kon);
            reseedCmd.ExecuteNonQuery();
            Kon.Close();

            using (StreamWriter writer = new StreamWriter(logFajl, true))
            {
                writer.WriteLine($"Obrisan projekat: Šifra: {IDTxt.Text}, Naziv: {NazivTxt.Text}");
            }

            MessageBox.Show("Projekat je obrisan!");

            PuniLV();
        }
        private void PrazniKontrole()
        {
            IDTxt.Clear();
            NazivTxt.Clear();
            DatumTxt.Clear();
            BudžetTxt.Clear();
            checkBox1.Checked = false;
            OpisTxt.Clear();
        }
        private void UnosProjekta()
        {
            if (NazivTxt.Text == "" || DatumTxt.Text == "" || BudžetTxt.Text == "" || OpisTxt.Text == "")
            {
                MessageBox.Show("Sva polja moraju biti popunjena!");
                return;
            }

            DateTime datumPocetka;
            if (!DateTime.TryParseExact(DatumTxt.Text, "dd.MM.yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out datumPocetka))
            {
                MessageBox.Show("Neispravan format datuma! (dd.MM.yyyy)");
                return;
            }

            if (!decimal.TryParse(BudžetTxt.Text, out decimal budzet))
            {
                MessageBox.Show("Budžet mora biti broj.");
                return;
            }


            Kon.Open();
            SqlCommand cmd = new SqlCommand("DodajProjekat", Kon)
             {
                    CommandType = CommandType.StoredProcedure
             };

             cmd.Parameters.AddWithValue("@Naziv", NazivTxt.Text);
             cmd.Parameters.AddWithValue("@DatumPocetka", datumPocetka);
             cmd.Parameters.AddWithValue("@Budzet", budzet);
             cmd.Parameters.AddWithValue("@ProjekatZavrsen", checkBox1.Checked);
             cmd.Parameters.AddWithValue("@Opis", OpisTxt.Text);

             cmd.ExecuteNonQuery();
             MessageBox.Show("Novi projekat je dodat!");
             Kon.Close();

             PuniLV();
             PrazniKontrole();
        }


        private void SaLV_NaKontrole()
        {
            foreach (ListViewItem item in listView1.SelectedItems)
            {
                id = Convert.ToInt32(item.SubItems[0].Text);

                IDTxt.Text = id.ToString();
                NazivTxt.Text = item.SubItems[1].Text;
                DatumTxt.Text = item.SubItems[2].Text;
                BudžetTxt.Text = item.SubItems[3].Text;
                checkBox1.Checked = Convert.ToBoolean(item.SubItems[4].Text);
                OpisTxt.Text = item.SubItems[5].Text;
            }
        }
        private void IzmenaProjekta()
        {
            if (NazivTxt.Text == "" || DatumTxt.Text == "" || BudžetTxt.Text == "" || OpisTxt.Text == "")
            {
                MessageBox.Show("Sva polja moraju biti popunjena!");
                return;
            }

            DateTime datumPocetka;
            if (!DateTime.TryParseExact(DatumTxt.Text, "dd.MM.yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out datumPocetka))
            {
                MessageBox.Show("Neispravan format datuma! (dd.MM.yyyy)");
                return;
            }

            if (!decimal.TryParse(BudžetTxt.Text, out decimal budzet))
            {
                MessageBox.Show("Budžet mora biti broj.");
                return;
            }

            Kon.Open();

            SqlCommand cmd = new SqlCommand("IzmenaProjekta", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@ProjekatID", SqlDbType.Int).Value = IDTxt.Text.ToString();
            cmd.Parameters.AddWithValue("@Naziv", NazivTxt.Text);
            cmd.Parameters.AddWithValue("@DatumPocetka", datumPocetka);
            cmd.Parameters.AddWithValue("@Budzet", budzet);
            cmd.Parameters.AddWithValue("@ProjekatZavrsen", checkBox1.Checked);
            cmd.Parameters.AddWithValue("@Opis", OpisTxt.Text);

            cmd.ExecuteNonQuery();
            MessageBox.Show("Projekat je izmenjen!");
            Kon.Close();

            PuniLV();
        }


        private void button3_Click_1(object sender, EventArgs e)
        {
            UnosProjekta();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            BrisiProjekat();
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            PrazniKontrole();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SaLV_NaKontrole();
        }

        private void pregledToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.ShowDialog();
        }

        private void dodavanjeAngažmanaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.Show();


        }

        private void button5_Click(object sender, EventArgs e)
        {
            IzmenaProjekta();
        }
    }
}
