﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace Nebojsa_Blagojević_A03
{
    public partial class Form2 : Form
    {
        SqlConnection Kon = new SqlConnection(@"Data Source=Komp_N\SQLEXPRESS;Initial Catalog=EIT_A03_EvidencijaRadnika;Integrated Security=True");

        public Form2()
        {
            InitializeComponent();
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            PuniPieChart();
            PuniDataGridView();
        }

        private void PuniDataGridView()
        {
                Kon.Open();
                SqlCommand cmd = new SqlCommand("PuniGridChart", Kon);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Period", numericUpDown1.Value);

                DataTable dt = new DataTable();
                dt.Load(cmd.ExecuteReader());

                dataGridView1.DataSource = dt;
                Kon.Close();
        }

        private void PuniPieChart()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniGridChart", Kon);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Period", numericUpDown1.Value);

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            chart1.Series.Clear();

            var pieSeries = new Series
            {
                ChartType = SeriesChartType.Pie,
                IsValueShownAsLabel = true
            };

            foreach (DataRow row in dt.Rows)
            {
                var brojRadnika = Convert.ToDouble(row["BrRadnika"]);
                pieSeries.Points.AddY(brojRadnika);

                pieSeries.Points[pieSeries.Points.Count - 1].LegendText = row["Godina"].ToString();
                pieSeries.Points[pieSeries.Points.Count - 1].Label = brojRadnika.ToString();
            }

            chart1.Series.Add(pieSeries);

            Kon.Close();
        }

        private void dodavanjeAngažmanaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.Show();
        }

        private void pregledToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
        }
    }
}