﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace Nebojsa_Blagojević_A03
{
    public partial class Form3: Form
    {
        SqlConnection Kon = new SqlConnection(@"Data Source=Komp_N\SQLEXPRESS;Initial Catalog=EIT_A03_EvidencijaRadnika;Integrated Security=True");

        SqlDataReader dr;

        int id = 0;
        public Form3()
        {
            InitializeComponent();
        }
        private void PrazniKontrole()
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
        }
        private void button4_Click(object sender, EventArgs e)
        {
            PrazniKontrole();
        }
        private void UnosAngazmana()
        {
            if (textBox3.Text == "" || textBox4.Text == "" || textBox5.Text == "")
            {
                MessageBox.Show("Sva polja moraju biti popunjena!");
                return;
            }
            DateTime datumPocetka;
            if (!DateTime.TryParseExact(textBox3.Text, "dd.MM.yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out datumPocetka))
            {
                MessageBox.Show("Neispravan format datuma! (dd.MM.yyyy)");
                return;
            }
            if (!decimal.TryParse(textBox4.Text, out decimal brsati))
            {
                MessageBox.Show("Broj sati mora biti broj.");
                return;
            }

            Kon.Open();

            SqlCommand cmd = new SqlCommand("DodajAngazman", Kon)
            {
                CommandType = CommandType.StoredProcedure
            };

            cmd.Parameters.Add(new SqlParameter("@DatumAngazovanja", SqlDbType.DateTime)).Value = datumPocetka;
            cmd.Parameters.Add(new SqlParameter("@BrojSati", SqlDbType.Decimal)).Value = brsati;
            cmd.Parameters.Add(new SqlParameter("@OpisPosla", SqlDbType.NVarChar)).Value = textBox5.Text;

            cmd.ExecuteNonQuery();
            MessageBox.Show("Angažman je uspešno unet!");
            Kon.Close();

            PuniListViewAngazman();
            PrazniKontrole();
        }




        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            UnosAngazmana();
        }
        private void PuniListViewAngazman()
        {
            listView1.Items.Clear();
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniListViewAngazman", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                ListViewItem red = new ListViewItem(dr[0].ToString());
                for (int i = 1; i <5; i++)
                {
                    if (i == 2)
                    {
                        DateTime datum = Convert.ToDateTime(dr[i]);
                        red.SubItems.Add(datum.ToString("dd.MM.yyyy"));
                    }
                    else
                    {
                        red.SubItems.Add(dr[i].ToString());
                    }
                }
                listView1.Items.Add(red);
            }

            Kon.Close();
           
        }

        private void SaLV_NaKontrole()
        {
            foreach (ListViewItem item in listView1.SelectedItems)
            {
                id = Convert.ToInt32(item.SubItems[0].Text);

                textBox1.Text = id.ToString();
                textBox2.Text = item.SubItems[1].Text;
                textBox3.Text = item.SubItems[2].Text;
                textBox4.Text = item.SubItems[3].Text;
                textBox5.Text = item.SubItems[4].Text;
            }
        }
        private void Form3_Load(object sender, EventArgs e)
        {
            PuniListViewAngazman();
            textBox1.Enabled = false;
            textBox2.Enabled = false;
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SaLV_NaKontrole();
        }
        private void BrisiAngazman()
        {
            int radnikID = int.Parse(textBox1.Text);
            int projekatID = int.Parse(textBox2.Text);

            Kon.Open();

            SqlCommand cmd = new SqlCommand("BrisiAngazman", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            SqlCommand reseedCmd = new SqlCommand("DBCC CHECKIDENT ('Angazman', RESEED, 0)", Kon);
            reseedCmd.ExecuteNonQuery();

            cmd.Parameters.AddWithValue("@RadnikID", radnikID);
            cmd.Parameters.AddWithValue("@ProjekatID", projekatID);

            cmd.ExecuteNonQuery();
            MessageBox.Show("Angažman je uspešno obrisan.");
 
            Kon.Close();
            PuniListViewAngazman();
            PrazniKontrole();
        }
        private void IzmenaAngazmana()
        {
            if (string.IsNullOrEmpty(textBox3.Text) || string.IsNullOrEmpty(textBox4.Text) || string.IsNullOrEmpty(textBox5.Text))
            {
                MessageBox.Show("Sva polja moraju biti popunjena!");
                return;
            }

            DateTime datumAngazovanja;
            if (!DateTime.TryParseExact(textBox3.Text, "dd.MM.yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out datumAngazovanja))
            {
                MessageBox.Show("Neispravan format datuma! (dd.MM.yyyy)");
                return;
            }

            if (!decimal.TryParse(textBox4.Text, out decimal brojSati))
            {
                MessageBox.Show("Broj sati mora biti broj.");
                return;
            }

            Kon.Open();

            SqlCommand cmd = new SqlCommand("IzmeniAngazman", Kon)
            {
                CommandType = CommandType.StoredProcedure
            };

            cmd.Parameters.Add(new SqlParameter("@RadnikID", SqlDbType.Int)).Value = Convert.ToInt32(textBox1.Text);
            cmd.Parameters.Add(new SqlParameter("@ProjekatID", SqlDbType.Int)).Value = Convert.ToInt32(textBox2.Text);
            cmd.Parameters.Add(new SqlParameter("@DatumAngazovanja", SqlDbType.DateTime)).Value = datumAngazovanja;
            cmd.Parameters.Add(new SqlParameter("@BrojSati", SqlDbType.Decimal)).Value = brojSati;
            cmd.Parameters.Add(new SqlParameter("@OpisPosla", SqlDbType.NVarChar)).Value = textBox5.Text;

            cmd.ExecuteNonQuery();
            MessageBox.Show("Podaci o angažmanu su uspešno izmenjeni!");
            Kon.Close();

            PuniListViewAngazman();
            PrazniKontrole();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            BrisiAngazman();
        }
        private void button5_Click(object sender, EventArgs e)
        {
            IzmenaAngazmana();
        }
        private void dodavanjeProjekataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
        }

        private void pregledProjekataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Show();
        }

    }
}
