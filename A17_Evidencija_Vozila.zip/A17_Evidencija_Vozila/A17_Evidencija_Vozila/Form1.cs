﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace A17_Evidencija_Vozila
{
    public partial class Form1 : Form
    {
        SqlConnection Kon = new SqlConnection(@"Data Source=Komp_N\SQLEXPRESS;Initial Catalog=4EIT_A17_EvidencijaVozila;Integrated Security=True");

        public Form1()
        {
            InitializeComponent();
            listView1.HeaderStyle = ColumnHeaderStyle.None;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            PuniComboBoxModel();
            PuniComboBoxBoja();
            PuniComboBoxGorivo();
            PuniLV();
            SaLVNaKontrole();
            foreach (ColumnHeader column in listView1.Columns)
            {
                column.Width = 97;
            }
            btnOdustani.Visible = false;
            izmeniToolStripMenuItem.Enabled = false;
            cmbModel.Text = string.Empty;
            cmbBoja.Text = string.Empty;
            cmbGorivo.Text = string.Empty;
        }
        private void PrazniKontrole()
        {
            txtSifra.Clear();
            txtReg.Clear();
            txtGp.Clear();
            txtPKm.Clear();
            txtCena.Clear();

            cmbModel.SelectedIndex = -1;
            cmbBoja.SelectedIndex = -1;
            cmbGorivo.SelectedIndex = -1;
        }
        private void PuniLV()
        {
            listView1.Items.Clear();
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniListBoxView", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            SqlDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                ListViewItem red = new ListViewItem(dr["VoziloID"].ToString());
                red.SubItems.Add(dr["Registracija"].ToString());
                red.SubItems.Add(dr["GodinaProizvodnje"].ToString());
                red.SubItems.Add(dr["PredjenoKM"].ToString());
                red.SubItems.Add(dr["Model"].ToString());
                red.SubItems.Add(dr["Boja"].ToString());
                red.SubItems.Add(dr["Gorivo"].ToString());
                red.SubItems.Add(dr["Cena"].ToString());

                listView1.Items.Add(red);
            }

            dr.Close();
            Kon.Close();
        }

        private void SaLVNaKontrole()
        {
            int id;
            foreach (ListViewItem item in listView1.SelectedItems)
            {
                id = Convert.ToInt32(item.SubItems[0].Text);

                txtSifra.Text = id.ToString();
                txtReg.Text = item.SubItems[1].Text;
                txtGp.Text = item.SubItems[2].Text;
                txtPKm.Text = item.SubItems[3].Text;
                cmbModel.Text = item.SubItems[4].Text;
                cmbBoja.Text = item.SubItems[5].Text;
                cmbGorivo.Text = item.SubItems[6].Text;
                txtCena.Text = item.SubItems[7].Text;

            }
        }
        private void UnesiVozilo()
        {
            Kon.Open();
            SqlCommand cmd = new SqlCommand("InsertNovoVozilo", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@Registracija", SqlDbType.VarChar).Value = txtReg.Text.ToString();
            cmd.Parameters.AddWithValue("@GodinaProizvodnje", SqlDbType.Int).Value = int.Parse(txtGp.Text.ToString());
            cmd.Parameters.AddWithValue("@Kilometraza", SqlDbType.Int).Value = int.Parse(txtPKm.Text.ToString());
            cmd.Parameters.AddWithValue("@ModelNaziv", SqlDbType.VarChar).Value = cmbModel.Text.ToString();
            cmd.Parameters.AddWithValue("@BojaNaziv", SqlDbType.VarChar).Value = cmbBoja.Text.ToString();
            cmd.Parameters.AddWithValue("@GorivoNaziv", SqlDbType.VarChar).Value = cmbGorivo.Text.ToString();
            cmd.Parameters.AddWithValue("@Cena", SqlDbType.Money).Value = decimal.Parse(txtCena.Text.ToString());

            cmd.ExecuteNonQuery();

            Kon.Close();
            PuniLV();
        }

        private void UpdateVozilo()
        {
            Kon.Open();

            using (SqlCommand cmd = new SqlCommand("AzurirajPodatkeVozilo", Kon))
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@Registracija", txtReg.Text);
                cmd.Parameters.AddWithValue("@GodinaProizvodnje", int.Parse(txtGp.Text));
                cmd.Parameters.AddWithValue("@Kilometraza", int.Parse(txtPKm.Text));
                cmd.Parameters.AddWithValue("@ModelNaziv", cmbModel.Text);
                cmd.Parameters.AddWithValue("@BojaNaziv", cmbBoja.Text);
                cmd.Parameters.AddWithValue("@GorivoNaziv", cmbGorivo.Text);
                cmd.Parameters.AddWithValue("@Cena", decimal.Parse(txtCena.Text));
                cmd.Parameters.AddWithValue("@VoziloID", int.Parse(txtSifra.Text));

                cmd.ExecuteNonQuery();
            }

            Kon.Close();

            PuniLV();

            MessageBox.Show($"Podaci o vozilu su izmenjeni u bazi\nŠifra vozila je: {txtSifra.Text}");
        }
        private void DeleteVozilo()
        {
            if (listView1.SelectedItems.Count > 0)
            {
                int voziloID = Convert.ToInt32(listView1.SelectedItems[0].SubItems[0].Text);

                Kon.Open();
                using (SqlCommand cmd = new SqlCommand("BrisiVozilo", Kon))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@VoziloID", SqlDbType.Int).Value = voziloID;
                    cmd.ExecuteNonQuery();
                }
                Kon.Close();

                PuniLV();
                MessageBox.Show($"Podaci o vozilu su izbrisani iz baze");
            }
        }
        private void PuniComboBoxModel()
        {
            Kon.Open();
            SqlCommand cmd = new SqlCommand("SELECT ModelID, Naziv FROM Model", Kon);
            cmd.CommandType = CommandType.Text;
            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            cmbModel.DataSource = dt;
            cmbModel.DisplayMember = "Naziv";
            cmbModel.ValueMember = "ModelID";
            Kon.Close();
        }
        private void PuniComboBoxBoja()
        {
            Kon.Open();
            SqlCommand cmd = new SqlCommand("SELECT Naziv FROM Boja", Kon);
            cmd.CommandType = CommandType.Text;
            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            cmbBoja.DataSource = dt;
            cmbBoja.DisplayMember = "Naziv";
            Kon.Close();
        }
        private void PuniComboBoxGorivo()
        {
            Kon.Open();
            SqlCommand cmd = new SqlCommand("SELECT Naziv FROM Gorivo", Kon);
            cmd.CommandType = CommandType.Text;
            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            cmbGorivo.DataSource = dt;
            cmbGorivo.DisplayMember = "Naziv";
            Kon.Close();
        }
        private void izmeniToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count > 0)
            {
                btnIzmena.PerformClick();
            }
            else
            {
                MessageBox.Show("Morate prvo selektovati vozilo za izmenu.");
            }
            UpdateVozilo();
        }
        private void btnIzmena_Click(object sender, EventArgs e)
        {
            btnOdustani.Visible = true;
            izmeniToolStripMenuItem.Enabled = true;
        }

        private void izlazToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnBrisanje_Click(object sender, EventArgs e)
        {
            DeleteVozilo();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SaLVNaKontrole();
        }

        private void btnOdustani_Click(object sender, EventArgs e)
        {
            SaLVNaKontrole();
            btnOdustani.Visible = false;
        }

        private void btnPrazni_Click(object sender, EventArgs e)
        {
            PrazniKontrole();
        }

        private void analizaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            //form2.FormClosed += (s, args) =>
            form2.ShowDialog();
            //this.Hide();
        }

        private void oAplikacijiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Aplikacija za evidenciju vozila.\n\nAutor: Neko\nVerzija: 1.0\nKratko uputstvo:\n- Koristite meni za dodavanje, izmenu i brisanje vozila.\n- Kliknite na analizu za prikaz grafikona.", "O aplikaciji");
        }
        private void btnDodavanje_Click(object sender, EventArgs e)
        {
            UnesiVozilo();
            MessageBox.Show($"Novo vozilo je dodato u bazu");
        }
    }
}
