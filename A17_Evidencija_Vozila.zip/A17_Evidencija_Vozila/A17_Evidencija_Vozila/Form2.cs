﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace A17_Evidencija_Vozila
{
    public partial class Form2 : Form
    {
        SqlConnection Kon = new SqlConnection(@"Data Source=Komp_N\SQLEXPRESS;Initial Catalog=4EIT_A17_EvidencijaVozila;Integrated Security=True");

        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            PuniComboBoxModel();
            cmbModel.Text = string.Empty;
        }
        private void PuniComboBoxModel()
        {
            Kon.Open();
            SqlCommand cmd = new SqlCommand("SELECT Naziv FROM Model", Kon);
            SqlDataReader dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            cmbModel.DataSource = dt;
            cmbModel.DisplayMember = "Naziv";
            Kon.Close();
        }
        private void PuniGridChart()
        {
            string selectedModel = cmbModel.Text;

            Kon.Open();
            SqlCommand cmd = new SqlCommand("PuniGridChart", Kon);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Model", selectedModel);

            SqlDataReader dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            dataGridView1.DataSource = dt;

            chart1.Series.Clear();
            Series series = new Series("Prosečna cena");
            series.ChartType = SeriesChartType.Pie;
            chart1.Series.Add(series);

            foreach (DataRow row in dt.Rows)
            {
                int godina = Convert.ToInt32(row["GodinaProizvodnje"]);
                decimal prosecnaCena = Convert.ToDecimal(row["ProsecnaCena"]);

                series.Points.AddXY(godina.ToString(), prosecnaCena);

                series.Points[series.Points.Count - 1].Label = $"{prosecnaCena:C}";
            }

            foreach (DataGridViewColumn column in dataGridView1.Columns)
            {
                column.Width = 212;
            }


            chart1.ChartAreas[0].Area3DStyle.Enable3D = true;
            Kon.Close();
        }
        private void btnIzadji_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnPrikazi_Click(object sender, EventArgs e)
        {
            PuniGridChart();
        }
    }
}
